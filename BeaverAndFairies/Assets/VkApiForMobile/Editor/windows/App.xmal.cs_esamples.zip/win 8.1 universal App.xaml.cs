﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Core;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using com.playGenesis.VkUnityPlugin;
using UnityPlayer;
using VK.WindowsPhone.SDK;
using VK.WindowsPhone.SDK_XAML;
using VK.WindowsPhone.SDK_XAML.Pages;


// The Blank Application template is documented at http://go.microsoft.com/fwlink/?LinkId=234227

namespace Su
{
	/// <summary>
	/// Provides application-specific behavior to supplement the default Application class.
	/// </summary>
	sealed partial class App : Application
	{
		private AppCallbacks appCallbacks;
		public SplashScreen splashScreen;
		
		/// <summary>
		/// Initializes the singleton application object.  This is the first line of authored code
		/// executed, and as such is the logical equivalent of main() or WinMain().
		/// </summary>
		public App()
		{
			this.InitializeComponent();
			appCallbacks = new AppCallbacks();
			//Added for vk plugin to work
            appCallbacks.Initialized += OnInitialized;
			//
        }

		//Method implementation modified for vk plugin to work
        /// <summary>
        /// Invoked when application is launched through protocol.
        /// Read more - http://msdn.microsoft.com/library/windows/apps/br224742
        /// </summary>
        /// <param name="args"></param>
        protected override void OnActivated(IActivatedEventArgs args)
		{
			string appArgs = "";
			
			switch (args.Kind)
			{
				case ActivationKind.Protocol:
					ProtocolActivatedEventArgs eventArgs = args as ProtocolActivatedEventArgs;
					splashScreen = eventArgs.SplashScreen;
					appArgs += string.Format("Uri={0}", eventArgs.Uri.AbsoluteUri);
			        if (eventArgs.Uri.AbsoluteUri.Contains("vk4473713://authorize"))
			        {
                        VKProtocolActivationHelper.HandleProtocolLaunch(eventArgs);
                    }
			        if (eventArgs.Uri.AbsoluteUri.Contains("vk4473713://usewebview"))
			        {
                        AppCallbacks.Instance.InvokeOnAppThread(() =>
                        {
                          UnityEngine.GameObject.Find("VkApi").GetComponent<VkApi>().nativeBridge.WSA_WebViewLogin();
                        }, false);
                        
			        }
			        break;
			}
			InitializeUnity(appArgs);
          
        }
		//Methods added for vk plugin to work 
        private void OnInitialized()
        {
            AppCallbacks.Instance.InvokeOnAppThread(() =>
            {
                InitVkApiLoginDelegate();
                InitVkApiLogoutDelegate();
                InitVkApiWebView();
                var appid = VkApi.VkSetts.VkAppId.ToString();
                VKSDK.Initialize(appid);
                VKSDK.AccessDenied += AccessDenied;
                VKSDK.AccessTokenReceived += RecievedToken;
            }, false);
        }
        private void InitVkApiLogoutDelegate()
        {
            var go = UnityEngine.GameObject.Find("VkApi");
            go.GetComponent<VkApi>().nativeBridge.OnWSALogout = () =>
            {
                AppCallbacks.Instance.InvokeOnUIThread(() =>
                {
                    try
                    {
                        VKSDK.Logout();
                    }
                    catch (Exception)
                    {
                        // ignored
                    }
                }, false);
            };
        }
        private void InitVkApiLoginDelegate()
        {
            var go = UnityEngine.GameObject.Find("VkApi");
            if (go == null)
            {
                throw new Exception("Vk not found, have exported the correct scene?");
            }
            go.GetComponent<VkApi>().nativeBridge.OnWSALogin = (scope, appid, forceoauth) =>
            {
                AppCallbacks.Instance.InvokeOnUIThread(() =>
                {
#if UNITY_WP_8_1
                    VKSDK.Authorize(scope, forceOAuth: forceoauth,revoke:true,loginType: LoginType.VKApp);
#else
                     VKSDK.Authorize(scope, forceOAuth: forceoauth,revoke:true,loginType: LoginType.WebView);
#endif

                }, false);
            };
        }

        private void AccessDenied(object sender, VKAccessDeniedEventArgs e)
        {
            AppCallbacks.Instance.InvokeOnAppThread(() =>
            {
                var gameObject = UnityEngine.GameObject.Find("VkApi");
                gameObject?.SendMessage("AccessDeniedMessage", "102#Access denied");
            }, false);
        }

        private void RecievedToken(object sender, VKAccessTokenReceivedEventArgs e)
        {
            AppCallbacks.Instance.InvokeOnAppThread(() =>
            {
                var token = e.NewToken;
                var gameObject = UnityEngine.GameObject.Find("VkApi");
                gameObject?.SendMessage("ReceiveNewTokenMessage",
                    token.AccessToken + "#1294039#" + token.ExpiresIn + "#" + token.UserId);
            }, false);
        }
        private void InitVkApiWebView()
        {
            var go = UnityEngine.GameObject.Find("VkApi");
            if (go == null)
            {
                throw new Exception("Vk not found, have you exported the correct scene?");
            }

            var unityWebView = go.GetComponent<com.playGenesis.VkUnityPlugin.WebView>();
            unityWebView.OpenWebViewAction = (openurl, closeurl) =>
            {
                AppCallbacks.Instance.InvokeOnUIThread(() =>
                {
                    var webviewpagecontrol = new WebViewPage();
                    webviewpagecontrol.OpenUrl = openurl;
                    webviewpagecontrol.CloseUrl = closeurl;

                    webviewpagecontrol.WebViewNavigatedToAction = (url) =>
                    {
                        AppCallbacks.Instance.InvokeOnAppThread(() =>
                        {
                            unityWebView.WebViewDone(url);
                        }, false);
                    };
                    webviewpagecontrol.ShowInPopup(Window.Current.Bounds.Width,
                        Window.Current.Bounds.Height);
                }, false);
            };
        }
        //end methods added for vk plugin to work 
        
		/// <summary>
        /// Invoked when application is launched via file
        /// Read more - http://msdn.microsoft.com/library/windows/apps/br224742
        /// </summary>
        /// <param name="args"></param>
        protected override void OnFileActivated(FileActivatedEventArgs args)
		{
			string appArgs = "";

			splashScreen = args.SplashScreen;
			appArgs += "File=";
			bool firstFileAdded = false;
			foreach (var file in args.Files)
			{
				if (firstFileAdded) appArgs += ";";
				appArgs += file.Path;
				firstFileAdded = true;
			}

			InitializeUnity(appArgs);
		}

		/// <summary>
		/// Invoked when the application is launched normally by the end user.  Other entry points
		/// will be used when the application is launched to open a specific file, to display
		/// search results, and so forth.
		/// </summary>
		/// <param name="args">Details about the launch request and process.</param>
		protected override void OnLaunched(LaunchActivatedEventArgs args)
		{
			splashScreen = args.SplashScreen;
			InitializeUnity(args.Arguments);
		}

		private void InitializeUnity(string args)
		{
#if UNITY_WP_8_1 || UNITY_UWP
			ApplicationView.GetForCurrentView().SuppressSystemOverlays = true;
#if UNITY_UWP
			if (Windows.Foundation.Metadata.ApiInformation.IsTypePresent("Windows.UI.ViewManagement.StatusBar"))
#endif
#pragma warning disable 4014
			{
				StatusBar.GetForCurrentView().HideAsync();
			}
#pragma warning restore 4014
#endif
			appCallbacks.SetAppArguments(args);
			Frame rootFrame = Window.Current.Content as Frame;

			// Do not repeat app initialization when the Window already has content,
			// just ensure that the window is active
			if (rootFrame == null && !appCallbacks.IsInitialized())
			{
				rootFrame = new Frame();
				Window.Current.Content = rootFrame;
				Window.Current.Activate();

				rootFrame.Navigate(typeof(MainPage));
			}

			Window.Current.Activate();
		}
	}
}
