﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ModNewtonsoft.Json;

namespace VK.WindowsPhone.SDK.API.Model
{
    public abstract class VKApiModelBase
    {

        public abstract void DeserializeFromJSON(JsonToken jsonToken);
    }
}
