﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

// The User Control item template is documented at http://go.microsoft.com/fwlink/?LinkId=234236

namespace VK.WindowsPhone.SDK_XAML.Pages
{
    public sealed partial class WebViewPage
    {
    
        public Action<string> WebViewNavigatedToAction;

        public WebViewPage()
        {
            InitializeComponent();
        }
        private bool canTalkToUnity=true;
        private string _openUrl;
        public string OpenUrl {
            get { return _openUrl; }
            set { canTalkToUnity = true;_openUrl = value; }
        }
        public string CloseUrl { get; set; }
   

        protected override void PrepareForLoad()
        {
            InitializeWebBrowser();
        }

        private void InitializeWebBrowser()
        {
            webView.NavigationStarting += BrowserOnNavigating;
            webView.NavigationCompleted += BrowserOnLoadCompleted;

            webView.Navigate(new Uri(OpenUrl));
        }

        private void BrowserOnLoadCompleted(WebView sender, WebViewNavigationCompletedEventArgs args)
        {
            if (!canTalkToUnity) return;

            if (!args.IsSuccess)
            {
                canTalkToUnity = false;
                progressBar.Visibility = Visibility.Collapsed;
                WebViewNavigatedToAction?.Invoke(args.Uri.AbsoluteUri + "*cancel=1");
                Close();
            }
            else
            {
                var url = args.Uri.AbsoluteUri;
                webView.Visibility = Visibility.Visible;
                progressBar.Visibility = Visibility.Collapsed;
                if (url.StartsWith(CloseUrl))
                {
                   canTalkToUnity = false;
                   WebViewNavigatedToAction?.Invoke(url);
                   Close();
                    
                }
            }
        }

        private void Close()
        {
            IsShown = false;
        }


        private void BrowserOnNavigating(WebView sender, WebViewNavigationStartingEventArgs args)
        {
            progressBar.Visibility = Visibility.Visible;
        }

        protected override void OnClosing()
        {
            base.OnClosing();
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            WebViewNavigatedToAction?.Invoke(webView.BaseUri.AbsoluteUri+"*cancel=1");
            Close();
        }
    }
}